# pylana - Python API for LANA Process Mining
This package provides a Python API for [LANA Process Mining](https://www.lana-labs.com/en/). 

**Attention**: This package is still in alpha state. Functions and parameters may be renamed and changed at any time.

This Branch is a pip installable distribution of the pylana package.

**Installation:**
```#!/usr/bin/env sh
pip install git+https://github.com/lanalabs/pylana.git@pylana_dist#egg=pylana
``` 
